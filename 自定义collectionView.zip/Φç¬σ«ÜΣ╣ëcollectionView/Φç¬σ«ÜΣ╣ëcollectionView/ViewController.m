//
//  ViewController.m
//  自定义collectionView
//
//  Created by 杨金发 on 16/9/5.
//  Copyright © 2016年 杨金发. All rights reserved.
//

#import "ViewController.h"
#import "YYCollectionViewCell.h"
#import "YYCollectionViewLayout.h"
#import "YYViewController.h"

//#define LINE 2
//#define SCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width
//#define PADDING 10
//#define ITEM_WIDTH   (SCREEN_WIDTH-PADDING*(LINE+1))/LINE
//

#define numberOfItems 11
static NSString*resuse=@"123";

@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,YYCollectionViewLayoutDelegate>

@property(nonatomic,strong)UICollectionView*collectionView;
@property(nonatomic,strong)YYCollectionViewLayout*layout;
@property(nonatomic,strong)NSMutableArray*dataSource;
@property(nonatomic,strong)NSMutableArray*itemHeights;


@end

@implementation ViewController

-(CGSize)YYCollectionViewLayoutForCollectionView:(UICollectionView *)collection withLayout:(YYCollectionViewLayout *)layout atIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(ITEM_WIDTH,[_itemHeights[indexPath.row] floatValue]);
}



-(void)initData
{
    _dataSource=[NSMutableArray arrayWithCapacity:numberOfItems];
    _itemHeights=[NSMutableArray arrayWithCapacity:numberOfItems];
    
    for (int i=0; i<numberOfItems; i++)
    {
        CGFloat height=200+arc4random_uniform(200);
        
        [_itemHeights addObject:@(height)];
        
    }
    
    
}
//numberOfItemsInSection
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return numberOfItems;
}
//cellForItemAtIndexPath
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    YYCollectionViewCell*cell=[collectionView dequeueReusableCellWithReuseIdentifier:resuse forIndexPath:indexPath];
    
    cell.itemImage.image=[UIImage imageNamed:[NSString stringWithFormat:@"%ld.jpeg",indexPath.row+1]];
    cell.itemImage.contentMode=UIViewContentModeScaleAspectFill;
    cell.itemName.text=[NSString stringWithFormat:@"美国原装进口Apple%ld.0",indexPath.row];
    cell.itemDetail.text=[NSString stringWithFormat:@"本产品为%dA级纯绿色无公害食品，富含天然矿物质。产品一经售出概不负责，最终解释权归卖家所有。产品如有雷同，纯属巧合。如有巧合，纯属意外。如有意外，纯属虚构。－－－非凡卖品有限公司",arc4random_uniform(10)];
    cell.nowPrice.text=[NSString stringWithFormat:@"$11%d",arc4random_uniform(99)];
    NSDictionary*attributeDict=@{NSStrikethroughStyleAttributeName:[NSNumber  numberWithInteger:NSUnderlineStyleSingle],NSStrikethroughColorAttributeName:[UIColor redColor]};
    
    cell.oldPrice.attributedText=[[NSAttributedString alloc]initWithString:[NSString stringWithFormat:@"$99%d",arc4random_uniform(99)] attributes:attributeDict];
    cell.saleNumber.text=[NSString stringWithFormat:@"月销9.%d万笔",arc4random_uniform(9)];
    
    
    
//    cell.backgroundColor=[UIColor yellowColor];
    return cell;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    _layout=[[YYCollectionViewLayout alloc]init];
    
    _layout.delegate=self;
    
    _collectionView=[[UICollectionView alloc]initWithFrame:self.view.bounds collectionViewLayout:_layout];
    _collectionView.delegate=self;
    _collectionView.dataSource=self;
    [self.view addSubview:_collectionView];
    _collectionView.backgroundColor=[UIColor whiteColor];
    
    [_collectionView registerNib:[UINib nibWithNibName:@"YYCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:resuse];
    
//    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:resuse];
    
    [self initData];
    
    
    UINavigationController*navi=[[UINavigationController alloc]initWithRootViewController:self];
    [UIApplication sharedApplication].delegate.window.rootViewController=navi;

    // Do any additional setup after loading the view, typically from a nib.
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
//    YYViewController*yvc=[[YYViewController alloc]initWithImage:[NSString stringWithFormat:@"%ld",indexPath.row+1] andWithPrice:[NSString stringWithFormat:@"¥%ld",indexPath.row+arc4random_uniform(100)] andSale:[NSString stringWithFormat:@"月销%ld.%d万笔",indexPath.row,arc4random_uniform(99)]];
//    [self.navigationController pushViewController:yvc animated:YES];
    
    UIStoryboard*stobry=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    YYViewController*vvc=[stobry instantiateViewControllerWithIdentifier:@"1234"];
    [self.navigationController pushViewController:vvc animated:YES];

    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
